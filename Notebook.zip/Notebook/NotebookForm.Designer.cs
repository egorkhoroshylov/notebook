﻿namespace Notebook
{
    partial class NotebookForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.DateTimePicker dtBirthday;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ListBox listBoxEntries;

        private void InitializeComponent()
        {
            txtName = new TextBox();
            txtAddress = new TextBox();
            txtPhone = new TextBox();
            dtBirthday = new DateTimePicker();
            btnAdd = new Button();
            listBoxEntries = new ListBox();
            txtSearch = new TextBox();
            btnSearch = new Button();
            btnEdit = new Button();
            btnDelete = new Button();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.Location = new Point(12, 12);
            txtName.Name = "txtName";
            txtName.PlaceholderText = "ПІБ";
            txtName.Size = new Size(200, 23);
            txtName.TabIndex = 0;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(12, 41);
            txtAddress.Name = "txtAddress";
            txtAddress.PlaceholderText = "Адреса";
            txtAddress.Size = new Size(200, 23);
            txtAddress.TabIndex = 1;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(12, 70);
            txtPhone.Name = "txtPhone";
            txtPhone.PlaceholderText = "Номер телефону";
            txtPhone.Size = new Size(200, 23);
            txtPhone.TabIndex = 2;
            txtPhone.TextChanged += txtPhone_TextChanged;
            // 
            // dtBirthday
            // 
            dtBirthday.Location = new Point(12, 99);
            dtBirthday.Name = "dtBirthday";
            dtBirthday.Size = new Size(200, 23);
            dtBirthday.TabIndex = 3;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(12, 128);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(200, 23);
            btnAdd.TabIndex = 4;
            btnAdd.Text = "Add";
            btnAdd.Click += btnAdd_Click;
            // 
            // listBoxEntries
            // 
            listBoxEntries.ItemHeight = 15;
            listBoxEntries.Location = new Point(12, 157);
            listBoxEntries.Name = "listBoxEntries";
            listBoxEntries.Size = new Size(360, 169);
            listBoxEntries.TabIndex = 5;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(12, 343);
            txtSearch.Name = "txtSearch";
            txtSearch.PlaceholderText = "Пошук за ПІБ";
            txtSearch.Size = new Size(200, 23);
            txtSearch.TabIndex = 6;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(218, 343);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 7;
            btnSearch.Text = "Пошук";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(385, 238);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(75, 23);
            btnEdit.TabIndex = 8;
            btnEdit.Text = "Редагувати";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(385, 279);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 9;
            btnDelete.Text = "Видалити";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // NotebookForm
            // 
            ClientSize = new Size(668, 423);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(txtName);
            Controls.Add(txtAddress);
            Controls.Add(txtPhone);
            Controls.Add(dtBirthday);
            Controls.Add(btnAdd);
            Controls.Add(listBoxEntries);
            Controls.Add(txtSearch);
            Controls.Add(btnSearch);
            Name = "NotebookForm";
            Text = "Notebook";
            ResumeLayout(false);
            PerformLayout();
        }
        private Button btnEdit;
        private Button btnDelete;
    }
}
