﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Notebook
{
    public partial class NotebookForm : Form
    {
        private List<NotebookEntry> entries = new List<NotebookEntry>();

        public NotebookForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            NotebookEntry entry = new NotebookEntry
            {
                FullName = txtName.Text,
                Address = txtAddress.Text,
                PhoneNumber = txtPhone.Text,
                Birthday = dtBirthday.Value,
                LastEdited = DateTime.Now
            };

            entries.Add(entry);
            RefreshList();
        }

        private void RefreshList()
        {
            listBoxEntries.Items.Clear();
            foreach (var entry in entries)
            {
                listBoxEntries.Items.Add(entry.ToString());
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string query = txtSearch.Text.Trim().ToLower();


            var found = entries
                .Where(e => e.FullName.ToLower().Contains(query))
                .ToList();

            listBoxEntries.Items.Clear();

            if (found.Count == 0)
            {
                MessageBox.Show("Користувача не знайдено", "Пошук", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            foreach (var entry in found)
            {
                listBoxEntries.Items.Add(entry.ToString());
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            int index = listBoxEntries.SelectedIndex;
            if (index == -1) return;

            entries[index].FullName = txtName.Text;
            entries[index].Address = txtAddress.Text;
            entries[index].PhoneNumber = txtPhone.Text;
            entries[index].Birthday = dtBirthday.Value;
            entries[index].LastEdited = DateTime.Now;

            RefreshList();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int index = listBoxEntries.SelectedIndex;
            if (index == -1) return;

            entries.RemoveAt(index);
            RefreshList();
        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

